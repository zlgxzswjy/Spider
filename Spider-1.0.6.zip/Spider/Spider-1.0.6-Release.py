import re
import requests
import sys
import queue
import threading
import getopt
import sqlite3
import random
import urllib.parse
import time

user_thread=1
key_t=""
ukey_t=""
key=[]
ukey=[]
output_file=""
url_file="url.txt"
level=1
rate=1
mode="text"
def param_init():
	opts,agrs=getopt.getopt(sys.argv[1:],"ht:k:o:f:r:m:l:n:")
	for op,value in opts:
		if op=="-t":
			global user_thread
			user_thread=int(value)
		elif op=="-k":
			global key_t
			global key
			key_t=value
			key=key_t.split(",")
		elif op=="-n":
			global ukey_t
			global ukey
			ukey_t=value
			ukey=ukey_t.split(",")
		elif op=="-o":
			global output_file
			output_file=value
		elif op=="-f":
			global url_file
			url_file=value
		elif op=="-l":
			global level
			level=int(value)-1
		elif op=="-r":
			global rate
			rate=int(value)
		elif op=="-m":
			global mode
			mode=value
			if((mode!='text') and (mode!='db')):
				usage()
				print("mode must 'text' or 'db'!!!")
				sys.exit()
		elif op=="-h":
			usage()
			sys.exit()
	if(url_file==""):
		usage()
		sys.exit()


def target_s(site,list_t,level_i,level_n,key,rate):
	if(level_i>level_n):
		return
	else:
		try:
			res = requests.get(site)
			data = res.text
		except:
			return
		url_list=[]
		link_list =re.findall(r"(?<=href=\").+?(?=\")|(?<=href=\').+?(?=\')" ,data)
		temp_list =re.findall(r"(?<=action=\").+?(?=\")|(?<=action=\').+?(?=\')" ,data)
		for url in temp_list:
			t=site+'/'+url;
			link_list.append(t)
		for url in link_list:
			if(len(link_list)==0):
				return
			if("http://" in url):
				if url not in list_t:
					list_t.append(url)
					url_list.append(url)
			if((len(list_t)%rate)==0 and len(list_t)!=0):
				time.sleep(1)
				print("\n")
		level_i+=1
		for url_t in url_list:
			target_s(url_t,list_t,level_i,level_n,key,rate)

def target_t(site_que,level,lists,key,rate,mode):
	while not site_que.empty():
		del lists[:]
		site=site_que.get()
		flist=[]
		target_s(site,lists,0,level,key,rate)
		datafile=urllib.parse.urlparse(site)
		datafile=datafile.netloc
		for i in lists:
			for j in key:
				if j in i:
					flist.append(i)
					break
		for i in flist:
			for j in ukey:
				if j in i:
					flist.remove(i)
					break
		if(mode=='db'):
			datafile+=".db"
			datafile="url/"+datafile
			cx=sqlite3.connect(datafile)
			cu=cx.cursor()
			cu.execute("create table url (id integer primary key autoincrement,url text)")
			for i in flist:
				cu.execute("insert into url values (NULL,?)",[i])
			cx.commit()
			cx.close()
		else:
			datafile+=".txt"
			datafile="url/"+datafile
			file=open(datafile,'a')
			for i in flist:
				try:
					file.write(i+'\n')
				except:
					print("write error!")
			file.close()

def build_wordlist():
	que_t=queue.Queue()
	fp=open(url_file,'r').readlines()
	for url in fp:
		url=''.join(url).strip('\n')
		que_t.put(url)
	return que_t

def main():
	try:
		param_init()
	except:
		usage()
		sys.exit()
	que=build_wordlist()
	list_n=[]
	threads=[]
	for i in range(user_thread):
		list=[]
		list_n.append(list)
		t=threading.Thread(target=target_t,args=(que,level,list_n[i],key,rate,mode,))
		threads.append(t)
	for i in threads:
		i.start()
	for i in threads:
		i.join()

def usage():
	print("""
		Spider for url  -version-1.0.3 --Written by WJY
		
		-h   Print the information of help
		-f   specified site file was crawling
		-k   specified keyword in url.Multiple key separated by ',' 
		-n  specified keyword not in url.Multiple key separated by ','
		-t   specified the count of threads
		-l   specified by crawling site depth
		-r   specified the frequency of crawling
		-m 	 specified the mode of store 'text' or 'db'
		
		Exampe:python3 Spider.py -f url.txt
		""")
if __name__ == "__main__":
    main()
