import re
import requests
import sys
import queue
import threading
import getopt
import sqlite3
import random
import urllib.parse
import time

user_thread=1
key=""
url_file="url.txt"
level=1
rate=1
mode="text"
def param_init():
	opts,agrs=getopt.getopt(sys.argv[1:],"ht:k:o:f:r:m:l:")
	for op,value in opts:
		if op=="-t":
			global user_thread
			user_thread=int(value)
		elif op=="-k":
			global key
			key=value
		elif op=="-f":
			global url_file
			url_file=value
		elif op=="-l":
			global level
			level=int(value)-1
		elif op=="-r":
			global rate
			rate=int(value)
		elif op=="-m":
			global mode
			mode=value
			if((mode!='text') and (mode!='db')):
				usage()
				print("mode must 'text' or 'db'!!!")
				sys.exit()
		elif op=="-h":
			usage()
			sys.exit()
	if(url_file==""):
		usage()
		sys.exit()

# 获取网页内容
def target_s(site,list_t,level_i,level_n,key,rate):
	if(level_i>level_n):
		return
	else:
		try:
			res = requests.get(site)
			data = res.text
		except:
			return
		url_list=[]
	# 利用正则查找所有连接
		link_list =re.findall(r"(?<=href=\").+?(?=\")|(?<=href=\').+?(?=\')" ,data)
		for url in link_list:
			if(len(link_list)==0):
				return
			if("http://" in url):
				if not key.strip():
					if url not in list_t:
						list_t.append(url)
						url_list.append(url)
				else:
					if key in url:
						if url not in list_t:
							list_t.append(url)
							url_list.append(url)
			if((len(list_t)%rate)==0 and len(list_t)!=0):
				time.sleep(1)
		level_i+=1
		for url_t in url_list:
			target_s(url_t,list_t,level_i,level_n,key,rate)
def target_t(site_que,level,lists,key,rate,mode):
	while not site_que.empty():
		del lists[:]
		site=site_que.get()
		target_s(site,lists,0,level,key,rate)
		datafile=urllib.parse.urlparse(site)
		datafile=datafile.netloc
		if(mode=='db'):
			datafile+=".db"
			datafile="url/"+datafile
			cx=sqlite3.connect(datafile)
			cu=cx.cursor()
			cu.execute("create table url (id integer primary key autoincrement,url text)")
			for i in lists:
				cu.execute("insert into url values (NULL,?)",[i])
			cx.commit()
			cx.close()
		else:
			datafile+=".txt"
			datafile="url/"+datafile
			file=open(datafile,'a')
			for i in lists:
				try:
					file.write(i+'\n')
				except:
					print("write error!")
			file.close()

def build_wordlist():
	que_t=queue.Queue()
	fp=open(url_file,'r').readlines()
	for url in fp:
		url=''.join(url).strip('\n')
		que_t.put(url)
	return que_t

def main():
	try:
		param_init()
	except:
		usage()
		sys.exit()
	
	que=build_wordlist()
	list_n=[]
	threads=[]
	for i in range(user_thread):
		list=[]
		list_n.append(list)
		t=threading.Thread(target=target_t,args=(que,level,list_n[i],key,rate,mode,))
		threads.append(t)
	for i in threads:
		i.start()
	for i in threads:
		i.join()

def usage():
	print("""
		Spider for url  -version-1.0.3 --Written by WJY
		
		-h   Print the information of help
		-f   specified site file was crawling
		-k   specified keyword in url
		-t   specified the count of threads
		-l   specified by crawling site depth
		-r   specified the frequency of crawling
		-m 	 specified the mode of store 'text' or 'db'
		
		Exampe:python3 Spider.py -f url.txt
		""")
if __name__ == "__main__":
    main()
